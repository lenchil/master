awsiot.eventstreamrpc
===========================

.. automodule:: awsiot.eventstreamrpc
